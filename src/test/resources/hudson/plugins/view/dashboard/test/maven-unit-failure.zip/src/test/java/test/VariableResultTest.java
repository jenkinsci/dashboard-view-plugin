package test;

import java.util.ArrayList;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import static org.junit.Assert.assertTrue;

@RunWith(Parameterized.class)
public class VariableResultTest {

  @Parameterized.Parameter(0)
  public boolean result;

  @Parameterized.Parameters(name = "{index}: {0}")
  public static Iterable<Object[]> getResults() {
    int testOk = Integer.valueOf(System.getProperty("testOk"));
    int testFail = Integer.valueOf(System.getProperty("testFail"));

    ArrayList<Object[]> result = new ArrayList<Object[]>(testOk + testFail);
    for (int i = 0; i < testOk; i++) {
      result.add(new Object[]{true});
    }
    for (int i = 0; i < testFail; i++) {
      result.add(new Object[]{false});
    }
    return result;
  }

  @Test
  public void testOnly() {
    assertTrue(result);
  }

}
